const { BedrockRuntimeClient, InvokeModelCommand } = require("@aws-sdk/client-bedrock-runtime");

const client = new BedrockRuntimeClient({ region: "eu-central-1" });

exports.handler = async (event) => {
    const corsHeaders = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
    };

    try {
        console.log("Received event:", JSON.stringify(event, null, 2));

        if (event.requestContext?.http?.method === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: corsHeaders,
                body: JSON.stringify({ message: "CORS preflight successful" })
            };
        }

        let body;
        try {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        } catch (parseError) {
            console.error("JSON parse error:", parseError);
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: "Invalid JSON in request body" })
            };
        }

        const userMessage = body?.message;
        if (!userMessage) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: "Message is required" })
            };
        }

        const systemPrompt = process.env.SYSTEM_MESSAGE || "You are a helpful AI assistant on Julia Baucher's CV website. Answer politely and concisely.";

        const bedrockRequest = {
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 512,
            temperature: 0.7,
            system: systemPrompt,
            messages: [
                {
                    role: "user",
                    content: userMessage
                }
            ]
        };

        console.log("Sending request to Bedrock:", JSON.stringify(bedrockRequest, null, 2));

        const command = new InvokeModelCommand({
            modelId: process.env.BEDROCK_MODEL_ID,
            contentType: "application/json",
            accept: "application/json",
            body: JSON.stringify(bedrockRequest)
        });

        const response = await client.send(command);
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));

        console.log("Bedrock response:", JSON.stringify(responseBody, null, 2));

        const generatedText = responseBody.content?.[0]?.text || "No response generated";

        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                reply: generatedText
            })
        };

    } catch (error) {
        console.error("Lambda error:", error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({
                error: "Internal server error",
                details: error.message
            })
        };
    }
};
